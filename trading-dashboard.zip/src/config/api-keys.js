export const CONFIGURATION = {
  binance: {
    key: 'a8174f8b4b0c2ae82a1c24e9ff0960dd4fde58265e3d2937c5d6c367e82401bc',
    secret: 'e17e358809671416e3a862f4dd9e00e7a40fcadd9a66fc1444beb6838c4422e9',
    exchangeType: 'futures' // spot is not supported yet
  },
  profile: {
    name: 'John Doe'
  }
};
